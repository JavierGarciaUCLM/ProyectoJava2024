import packClasses.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainFrame extends JFrame {
    private ButtonGroup dispenserButtonGroup;
    private JTextField textFieldMedicine;
    private JButton buttonMedicine;
    private JButton buttonInformationFlyer;
    private JButton buttonRefill;
    private JButton buttonDispenseList;
    private JTextField textFieldCompanyName;

    private JLabel lbMedicine;
    private JLabel lbCompanyName;
    private JLabel lbNumItems;
    private JTextField textFieldNumItems;
    private JTextArea xTextArea;
    private JLabel lbDispensers;
    private JRadioButton viewDispenser4RadioButton;
    private JRadioButton viewDispenser3RadioButton;
    private JRadioButton viewDispenser2RadioButton;
    private JRadioButton viewDispenser1RadioButton;
    private JPanel mainPanel;
    private JLabel logo;

    private Pharmacy farmacia; // References to  Pharmacy

    public MainFrame(Pharmacy farmacia) {
        this.farmacia = farmacia; // Initializes teh pharmacy
        setContentPane(mainPanel);
        setTitle("Pharmacy");
        setSize(1400, 800);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);
        dispenserButtonGroup = new ButtonGroup();
        dispenserButtonGroup.add(viewDispenser1RadioButton);
        dispenserButtonGroup.add(viewDispenser2RadioButton);
        dispenserButtonGroup.add(viewDispenser3RadioButton);
        dispenserButtonGroup.add(viewDispenser4RadioButton);
        xTextArea.setFont(new Font("Courier New", Font.PLAIN, 8));

        // add an ActionListener to buttonInformationFlyer
        buttonInformationFlyer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = textFieldMedicine.getText(); // gets text from textFieldCompanyName
                String nameCompany=textFieldCompanyName.getText();


                int[] positionmedicamento = farmacia.findPositions(name);
                int[] positionmedicamento2 = farmacia.findPositions(name, nameCompany);
                //if you do not specify the company name
                if (positionmedicamento[0] != -1) {
                    int p = positionmedicamento[0];
                    int i = positionmedicamento[1];


                    Medicine medicamentoEncontrado = farmacia.dispensers[p].dispenser[19][i];
                    if (medicamentoEncontrado != null) {
                        xTextArea.setText(medicamentoEncontrado.getIndications());


                    } else {
                        xTextArea.setText("Medicine not found or run out.");
                    }
                } else {
                    xTextArea.setText("Medicine not found or run out.");
                }
            }
        });
        viewDispenser1RadioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                xTextArea.setText("");


                for (int i = 0; i < 20; i++) {
                    for (int j = 0; j < 15; j++) {
                        if (i < 20-farmacia.dispensers[0].dispenser[20][j].getUnits()) {

                            xTextArea.append(String.format("%-15s", "0"));


                        } else {

                            xTextArea.append(String.format("%-15s","1"));

                        }
                    }

                    xTextArea.append("\n");
                }
                xTextArea.append("\n");

                // A単adir los nombres de los medicamentos

                for(int j = 0; j < 15; j++){
                    {

                        String nombreMedicamento = farmacia.dispensers[0].dispenser[20][j].getNameMedicine();

                        xTextArea.append(String.format("%-15s", nombreMedicamento));

                    }
                }

                xTextArea.append("\n");
                for(int j = 0; j < 15; j++){
                    {

                        String nombreEmpresa = farmacia.dispensers[0].dispenser[20][j].getManufacturer();

                        xTextArea.append(String.format("%-15s", nombreEmpresa));
                    }
                }
            }
        });
        viewDispenser2RadioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                xTextArea.setText("");


                for (int i = 0; i < 20; i++) {
                    for (int j = 0; j < 15; j++) {
                        if (i < 20-farmacia.dispensers[1].dispenser[20][j].getUnits()) {


                            xTextArea.append(String.format("%-15s", "0"));


                        } else {

                            xTextArea.append(String.format("%-15s","1"));

                        }
                    }

                    xTextArea.append("\n");
                }
                xTextArea.append("\n");

                // A単adir los nombres de los medicamentos

                for(int j = 0; j < 15; j++){
                    {

                        String nombreMedicamento = farmacia.dispensers[1].dispenser[20][j].getNameMedicine();

                        xTextArea.append(String.format("%-15s", nombreMedicamento));
                    }
                }
                xTextArea.append("\n");
                for(int j = 0; j < 15; j++){
                    {

                        String nombreEmpresa = farmacia.dispensers[1].dispenser[20][j].getManufacturer();

                        xTextArea.append(String.format("%-15s", nombreEmpresa));
                    }
                }
            }
        });
        viewDispenser3RadioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                xTextArea.setText("");


                for (int i = 0; i < 20; i++) {
                    for (int j = 0; j < 15; j++) {
                        if (i < 20-farmacia.dispensers[2].dispenser[20][j].getUnits()) {

                            xTextArea.append(String.format("%-15s", "0"));


                        } else {

                            xTextArea.append(String.format("%-15s","1"));

                        }
                    }

                    xTextArea.append("\n");
                }
                xTextArea.append("\n");

                // A単adir los nombres de los medicamentos

                for(int j = 0; j < 15; j++){
                    {

                        String nombreMedicamento = farmacia.dispensers[2].dispenser[20][j].getNameMedicine();

                        xTextArea.append(String.format("%-15s", nombreMedicamento));
                    }
                }
                xTextArea.append("\n");
                for(int j = 0; j < 15; j++){
                    {

                        String nombreEmpresa = farmacia.dispensers[2].dispenser[20][j].getManufacturer();

                        xTextArea.append(String.format("%-15s", nombreEmpresa));
                    }
                }
            }
        });
        viewDispenser4RadioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                xTextArea.setText("");


                for (int i = 0; i < 20; i++) {
                    for (int j = 0; j < 15; j++) {
                        if (i < 20-farmacia.dispensers[3].dispenser[20][j].getUnits()) {

                            xTextArea.append(String.format("%-15s", "0"));


                        } else {

                            xTextArea.append(String.format("%-15s","1"));

                        }
                    }

                    xTextArea.append("\n");
                }
                xTextArea.append("\n");

                // A単adir los nombres de los medicamentos

                for(int j = 0; j < 15; j++){
                    {

                        String nombreMedicamento = farmacia.dispensers[3].dispenser[20][j].getNameMedicine();

                        xTextArea.append(String.format("%-15s", nombreMedicamento));
                    }
                }
                xTextArea.append("\n");
                for(int j = 0; j < 15; j++){
                    {

                        String nombreEmpresa = farmacia.dispensers[3].dispenser[20][j].getManufacturer();

                        xTextArea.append(String.format("%-15s", nombreEmpresa));
                    }
                }
            }
        });
        buttonMedicine.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                xTextArea.setText("");

                String nameMedicine=textFieldMedicine.getText();
                int amount=Integer.parseInt(textFieldNumItems.getText());
                String nameCompany=textFieldCompanyName.getText();

                Medicine Medicamento = new Medicine();
                Medicamento.setName(nameMedicine);
                Medicamento.setUnits(amount);
                Medicamento.setManufacturer(nameCompany);
                int cantidadRestante;
                int counter = 0;
                if (nameCompany.isEmpty()) {
                    cantidadRestante=farmacia.dispendMedicicine(nameMedicine, amount);
                    for (int i = 0; i < 4; i++) {
                        for (int j = 0; j < 15; j++) {
                            if (nameMedicine.equals(farmacia.dispensers[i].dispenser[20][j].getNameMedicine())) {
                                counter++;
                            }
                        }
                    }
                } else {
                    cantidadRestante=farmacia.dispendMedicicine(nameMedicine, amount, nameCompany);
                    for (int i = 0; i < 4; i++) {
                        for (int j = 0; j < 15; j++) {
                            if (nameMedicine.equals(farmacia.dispensers[i].dispenser[20][j].getNameMedicine()) && nameCompany.equals(farmacia.dispensers[i].dispenser[20][j].getManufacturer())) {
                                counter++;
                            }
                        }
                    }
                }




                if (counter == 0) {
                    xTextArea.setText("This medicine does not exist with this company");

                } else if (cantidadRestante == 0) {

                    xTextArea.setText("Amount successfully withdrawn");
                    farmacia.agregarMedicamentoDispensado(Medicamento,amount);

                } else {xTextArea.setText("Not enough medicine,refilling all dispensers.\n\nRemaining Amount: "+cantidadRestante);
                    farmacia.refillStockAll();
                    farmacia.agregarMedicamentoDispensado(Medicamento,(amount-cantidadRestante));
                }


            }
        });
        buttonRefill.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                xTextArea.setText("");

                String nameCompany=textFieldCompanyName.getText();
                String nameMedicine=textFieldMedicine.getText();
                int amount=Integer.parseInt(textFieldNumItems.getText());
                if (nameCompany.isEmpty()) {
                    farmacia.refillOneMedicine(nameMedicine, amount);
                } else {
                    farmacia.refillOneMedicine(nameMedicine, amount, nameCompany);
                }
                xTextArea.setText("Successful");

            }
        });
        buttonDispenseList.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                Medicine[] medicamentosDispensados =farmacia.getMedicamentosDispensados();

                xTextArea.setText("");

                for (int i = 0; i < farmacia.getContadorMedicamentos(); i++) {
                    Medicine m = medicamentosDispensados[i];
                    xTextArea.append("Name: " + m.getNameMedicine() + "     Amount Dispensed: " +medicamentosDispensados[i].getUnits() + "     Company: " + m.getManufacturer() +"\n");
                }

            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {

            Dispenser[] dispensers = new Dispenser[4];
            // Each dispenser is initialized
            // dispensers[0] = new Dispenser().....depending on what you need. If more are added, modify function new Dispenser[x];

            for(int i=0;i<4;i++){
                dispensers[i]= new Dispenser();//Dispenser initialized
            }


            Pharmacy farmacia = new Pharmacy(dispensers);



            new MainFrame(farmacia).setVisible(true);


            //By default, each dispenser is empty and will not be counted when searching, here they can be manually filled.

            fillColumn(farmacia.dispensers[0], 21, 0, 1, "for pain", "Bayer", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[0], 21, 1, 1, "for pain", "Bayer", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[0], 21, 2, 1, "for pain", "Bayern", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[0], 21, 3, 1, "for pain", "Albacete", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[0], 21, 4, 1, "for pain", "Valencia", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[0], 21, 5, 1, "for pain", "Bayer", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[0], 21, 6, 1, "for pain", "Bayer", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[0], 21, 7, 1, "for pain", "Bayer", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[0], 21, 8, 1, "for pain", "Bayer", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[0], 21, 9, 1, "for pain", "Bayer", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[0], 21, 10, 1, "for pain", "Bayer", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[0], 21, 11, 1, "for pain", "Bayer", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[0], 21, 12, 1, "for pain", "Bayer", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[0], 21, 13, 1, "for pain", "Bayer", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[0], 21, 14, 1, "for pain", "Bayer", "Paracetamol", 1);

            fillColumn(farmacia.dispensers[1], 21, 0, 1, "for pain", "Bayer", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[1], 21, 1, 1, "for pain", "Bayer", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[1], 21, 2, 1, "for pain", "Bayer", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[1], 21, 3, 1, "for pain", "Bayer", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[1], 21, 4, 1, "for pain", "Bayer", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[1], 21, 5, 1, "for pain", "Bayer", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[1], 21, 6, 1, "for pain", "Bayer", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[1], 21, 7, 1, "for pain", "Bayer", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[1], 21, 8, 1, "for pain", "Bayer", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[1], 21, 9, 1, "for pain", "Bayer", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[1], 21, 10, 1, "for pain", "Bayer", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[1], 21, 11, 1, "for pain", "Bayer", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[1], 21, 12, 1, "for pain", "Bayer", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[1], 21, 13, 1, "for pain", "Bayer", "Paracetamol", 1);
            fillColumn(farmacia.dispensers[1], 21, 14, 1, "for pain", "Bayer", "Paracetamol", 1);

            fillColumn(farmacia.dispensers[2], 21, 0, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[2], 21, 1, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[2], 21, 2, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[2], 21, 3, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[2], 21, 4, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[2], 21, 5, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[2], 21, 6, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[2], 21, 7, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[2], 21, 8, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[2], 21, 9, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[2], 21, 10, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[2], 21, 11, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[2], 21, 12, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[2], 21, 13, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[2], 21, 14, 1, "for fever", "Pzifer", "Ibuprofeno", 1);

            fillColumn(farmacia.dispensers[3], 21, 0, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[3], 21, 1, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[3], 21, 2, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[3], 21, 3, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[3], 21, 4, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[3], 21, 5, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[3], 21, 6, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[3], 21, 7, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[3], 21, 8, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[3], 21, 9, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[3], 21, 10, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[3], 21, 11, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[3], 21, 12, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[3], 21, 13, 1, "for fever", "Pzifer", "Ibuprofeno", 1);
            fillColumn(farmacia.dispensers[3], 21, 14, 1, "for fever", "Pzifer", "Ibuprofeno", 1);

        });
    }

    private static void fillColumn(Dispenser dispenser, int totalRows, int column, int id, String indications, String manufacturer, String nameMedicine, int unitsPerBox) {
        for(int i = 0; i < 20; i++) {
            dispenser.dispenser[i][column] = new Medicine(id, indications, manufacturer, nameMedicine, unitsPerBox);
        }
        dispenser.dispenser[20][column] = new Medicine(id, indications, manufacturer, nameMedicine, 20);
    }
}








