//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package packClasses;

public class Medicine {
    int id;
    String indications;
    String manufacturer;
    String nameMedicine;
    int units;

    public Medicine() {
        this.id = -1;
        this.indications = "";
        this.manufacturer = "";
        this.nameMedicine = "";
        this.units = 0;
    }

    public Medicine(int id, String indications, String manufacturer, String nameMedicine, int units) {
        this.id = id;
        this.indications = indications;
        this.manufacturer = manufacturer;
        this.nameMedicine = nameMedicine;
        this.units = units;
    }

    public int getId() {
        return this.id;
    }

    public String getIndications() {
        return this.indications;
    }

    public int getUnits() {
        return this.units;
    }

    public String getManufacturer() {
        return this.manufacturer;
    }

    public String getNameMedicine() {
        return this.nameMedicine;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setIndications(String indications) {
        this.indications = indications;
    }

    public void setName(String nameMedicine) {
        this.nameMedicine = nameMedicine;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public void setUnits(int units) {
        this.units = units;
    }
}
