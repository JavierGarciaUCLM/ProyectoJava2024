//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package packClasses;

import javax.swing.JFrame;

public class Pharmacy extends JFrame {
    public packClasses.Dispenser[] dispensers = new packClasses.Dispenser[4];
    private packClasses.Medicine[] medicamentosDispensados;
    private int contadorMedicamentos = 0;

    public Pharmacy(packClasses.Dispenser[] dispensers) {
        for(int i = 0; i < this.dispensers.length; ++i) {
            this.dispensers[i] = new packClasses.Dispenser();
        }

        this.medicamentosDispensados = new packClasses.Medicine[1000];
    }

    public packClasses.Medicine[] getMedicamentosDispensados() {
        return this.medicamentosDispensados;
    }

    public int getContadorMedicamentos() {
        return this.contadorMedicamentos;
    }

    public int[] findPositions(String name) {
        int[] isThere = new int[]{-1, -1};

        for(int i = 0; i < 4; ++i) {
            int positions = this.dispensers[i].findMedicine(name);
            if (positions != -1) {
                isThere[0] = i;
                isThere[1] = positions;
                return isThere;
            }
        }

        return isThere;
    }

    public int[] findPositions(String name, String nameCompany) {
        int[] isThere = new int[]{-1, -1};

        for(int i = 0; i < 4; ++i) {
            int positions = this.dispensers[i].findMedicine(name, nameCompany);
            if (positions != -1) {
                isThere[0] = i;
                isThere[1] = positions;
                return isThere;
            }
        }

        return isThere;
    }

    public int dispendMedicicine(String name, int amount) {
        for(int i = 0; i < 4; ++i) {
            int x = this.dispensers[i].takeMedicine(name, amount);
            if (x == 0) {
                ++i;
            }

            amount -= x;
            if (amount == 0) {
                return 0;
            }

            --i;
        }

        return amount;
    }

    public int dispendMedicicine(String name, int amount, String manufacturer) {
        for(int i = 0; i < 4; ++i) {
            int x = this.dispensers[i].takeMedicine(name, amount, manufacturer);
            if (x == 0) {
                ++i;
            }

            amount -= x;
            if (amount == 0) {
                return 0;
            }

            --i;
        }

        return amount;
    }

    public void refillStockAll() {
        for(int i = 0; i < 4; ++i) {
            this.dispensers[i].refillStockAll();
        }

    }

    public void refillOneMedicine(String name, int amount) {
        for(int i = 3; i >= 0; --i) {
            for(int j = 14; j >= 0; --j) {
                if (this.dispensers[i].dispenser[20][j].getNameMedicine().equals(name)) {
                    this.dispensers[i].dispenser[20][j].units += amount;
                    amount = 0;
                    if (this.dispensers[i].dispenser[20][j].units > 20) {
                        amount = this.dispensers[i].dispenser[20][j].units - 20;
                        this.dispensers[i].dispenser[20][j].units = 20;
                    }
                }

                if (amount == 0) {
                    return;
                }
            }
        }

    }

    public void refillOneMedicine(String name, int amount, String nameCompany) {
        for(int i = 3; i >= 0; --i) {
            for(int j = 14; j >= 0; --j) {
                if (this.dispensers[i].dispenser[20][j].getNameMedicine().equals(name) && this.dispensers[i].dispenser[20][j].getManufacturer().equals(nameCompany)) {
                    this.dispensers[i].dispenser[20][j].units += amount;
                    amount = 0;
                    if (this.dispensers[i].dispenser[20][j].units > 20) {
                        amount = this.dispensers[i].dispenser[20][j].units - 20;
                        this.dispensers[i].dispenser[20][j].units = 20;
                    }
                }

                if (amount == 0) {
                    return;
                }
            }
        }

    }

    public void agregarMedicamentoDispensado(packClasses.Medicine medicamento, int cantidad) {
        for(int i = 0; i < this.contadorMedicamentos; ++i) {
            if (this.medicamentosDispensados[i].nameMedicine.equals(medicamento.nameMedicine) && this.medicamentosDispensados[i].manufacturer.equals(medicamento.manufacturer)) {
                packClasses.Medicine var10000 = this.medicamentosDispensados[i];
                var10000.units += cantidad;
                return;
            }
        }

        if (this.contadorMedicamentos < this.medicamentosDispensados.length) {
            this.medicamentosDispensados[this.contadorMedicamentos] = medicamento;
            this.medicamentosDispensados[this.contadorMedicamentos].units = cantidad;
            ++this.contadorMedicamentos;
        }

    }
}
