//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package packClasses;

public class Dispenser {
    public packClasses.Medicine[][] dispenser = new packClasses.Medicine[21][15];

    public Dispenser() {
        for(int i = 0; i < 21; ++i) {
            for(int j = 0; j < 15; ++j) {
                this.dispenser[i][j] = new packClasses.Medicine();
            }
        }

    }

    public int findMedicine(String name) {
        for(int i = 0; i < 15; ++i) {
            if (this.dispenser[20][i].getNameMedicine().equals(name) && this.dispenser[20][i].units > 0) {
                return i;
            }
        }

        return -1;
    }

    public int findMedicine(String name, String manufacturer) {
        for(int i = 0; i < 15; ++i) {
            if (this.dispenser[20][i].getNameMedicine().equals(name) && this.dispenser[20][i].units > 0 && this.dispenser[20][i].getManufacturer().equals(manufacturer)) {
                return i;
            }
        }

        return -1;
    }

    public int takeMedicine(String name, int x) {
        int numberMedicine = 0;
        if (x == 0) {
            return numberMedicine;
        } else {
            int column = this.findMedicine(name);
            if (column > -1) {
                if (this.dispenser[20][column].units - x < 0) {
                    numberMedicine += this.dispenser[20][column].units;
                    this.dispenser[20][column].units = 0;
                    return numberMedicine;
                }

                numberMedicine += x;
                this.dispenser[20][column].units -= x;
            }

            return numberMedicine;
        }
    }

    public int takeMedicine(String name, int x, String manufacturer) {
        int numberMedicine = 0;
        if (x == 0) {
            return numberMedicine;
        } else {
            int column = this.findMedicine(name, manufacturer);
            if (column > -1) {
                if (this.dispenser[20][column].units - x < 0) {
                    numberMedicine += this.dispenser[20][column].units;
                    this.dispenser[20][column].units = 0;
                    return numberMedicine;
                }

                numberMedicine += x;
                this.dispenser[20][column].units -= x;
            }

            return numberMedicine;
        }
    }

    public void refillStockAll() {
        for(int i = 0; i < 15; ++i) {
            this.dispenser[20][i].units = 20;
        }

    }
}
